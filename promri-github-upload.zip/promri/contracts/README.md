# Deploying PromriEscrow

This is a real, compiled Solidity contract (`contracts/PromriEscrow.sol`) —
verified to compile cleanly against OpenZeppelin 5.x as part of building
this repo. It hasn't been tested against a live network from here (this
environment can't reach a live chain), so **deploy to testnet first and
actually run through fund → accept → close before touching real money.**

## Option A — zero signups, testnet (recommended to start)

Base Sepolia has a public RPC that needs no API key or account:
`https://sepolia.base.org`. You'll need a small amount of free Sepolia
ETH from a faucet (search "Base Sepolia faucet") to pay gas.

```bash
cd contracts
npm install
export RPC_URL="https://sepolia.base.org"
export PRIVATE_KEY="0x..."   # a fresh wallet's private key — this becomes
                              # the contract owner, i.e. the same key you'll
                              # put in the Worker's PLATFORM_PRIVATE_KEY secret
npx hardhat run scripts/deploy.js --network base_sepolia
```

This prints the deployed contract address. Put that address into:
- `worker/wrangler.toml` → `[vars] ESCROW_CONTRACT_ADDRESS`
- `website/index.html` → `window.PROMRI_ESCROW_ADDRESS`

Set `EVM_CHAIN_ID = "84532"` (Base Sepolia) in the Worker's `[vars]` —
that's already the default in `wrangler.toml`.

## Option B — a different chain / mainnet later

Same script, different `--network` and RPC. Add a network block to
`hardhat.config.js` (copy the `base_sepolia` one) pointing `url` at your
provider (Alchemy/Infura/etc. — mainnet RPCs generally do require a free
account with one of these), update `EVM_CHAIN_ID` in the Worker to match,
and re-run the deploy script.

## What owns the contract, and why that key matters

Whichever private key deploys the contract becomes its `owner` — the
only address that can call `startSession`, `closeSession`, or
`slashAndClose`. That's meant to be the platform's own operational key
(the same one in the Worker's `PLATFORM_PRIVATE_KEY` secret), not any
individual host's or renter's key. If that key leaks, whoever has it can
start/close/slash any session — treat it with the same care as a
production database credential, not a config value.

## Verifying it compiles yourself

```bash
cd contracts
npm install
node compile.js
```

This uses the `solc` npm package directly (pure JS/WASM, no binary
download) rather than `npx hardhat compile`, which tries to download the
compiler from `binaries.soliditylang.org` and will fail in network-
restricted environments. Both produce the same bytecode; `compile.js` is
just the fallback that doesn't need that one extra download.
