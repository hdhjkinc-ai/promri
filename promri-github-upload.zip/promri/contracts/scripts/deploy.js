const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with account:", deployer.address);

  const PromriEscrow = await hre.ethers.getContractFactory("PromriEscrow");
  const contract = await PromriEscrow.deploy(deployer.address);
  await contract.waitForDeployment();

  const address = await contract.getAddress();
  console.log("PromriEscrow deployed to:", address);
  console.log("Owner (platform operator):", deployer.address);
  console.log("");
  console.log("Next: put this address in worker/wrangler.toml's [vars] ESCROW_CONTRACT_ADDRESS");
  console.log("and in website/index.html's window.PROMRI_ESCROW_ADDRESS.");
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
