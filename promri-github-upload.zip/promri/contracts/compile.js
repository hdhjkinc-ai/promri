const solc = require("solc");
const fs = require("fs");
const path = require("path");

function findImports(importPath) {
  try {
    const resolved = path.join(__dirname, "node_modules", importPath);
    return { contents: fs.readFileSync(resolved, "utf8") };
  } catch (e) {
    return { error: "File not found: " + importPath };
  }
}

const source = fs.readFileSync("contracts/PromriEscrow.sol", "utf8");
const input = {
  language: "Solidity",
  sources: { "PromriEscrow.sol": { content: source } },
  settings: {
    outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } },
    optimizer: { enabled: true, runs: 200 },
  },
};

const output = JSON.parse(solc.compile(JSON.stringify(input), { import: findImports }));

let hasError = false;
for (const err of output.errors || []) {
  if (err.severity === "error") { hasError = true; console.error(err.formattedMessage); }
  else console.warn(err.formattedMessage);
}
if (hasError) process.exit(1);

const contract = output.contracts["PromriEscrow.sol"]["PromriEscrow"];
fs.writeFileSync("PromriEscrow.abi.json", JSON.stringify(contract.abi, null, 2));
fs.writeFileSync("PromriEscrow.bytecode.txt", contract.evm.bytecode.object);
console.log("COMPILE_OK bytecode_length=" + contract.evm.bytecode.object.length);
console.log(JSON.stringify(contract.abi.map(x => x.type === "function" ? x.name : x.type)));
