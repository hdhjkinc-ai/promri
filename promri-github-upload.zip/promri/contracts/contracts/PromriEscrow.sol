// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * PromriEscrow — the actual money-movement contract behind the Worker's
 * relay calls (open_stream / close_stream / slash / check_escrow).
 *
 * Design choice, stated plainly: this settles per-session at close time
 * (amount owed = elapsed seconds * agreed rate, capped at what was
 * deposited) rather than moving tokens on-chain every second. True
 * continuous on-chain streaming (what Superfluid actually does) needs
 * its own token-flow accounting layer — that's a separate, much larger
 * protocol to integrate, not something to reimplement here. This
 * contract gets you the same economic outcome — pay only for what ran —
 * settled in one or two transactions instead of thousands.
 *
 * Access model: the renter funds and can be refunded; only the contract
 * owner (the address the relay-service signs with) can start, close, or
 * slash a session. That owner key belongs to the platform operator, not
 * to any individual host or renter — protect it accordingly (see
 * relay-service/README.md).
 */
contract PromriEscrow is Ownable, ReentrancyGuard {
    enum Status { None, Funded, Active, Closed }

    struct Session {
        address renter;
        address host;
        uint256 ratePerSecond; // wei per second, agreed off-chain and passed in at funding time
        uint256 deposited;     // remaining escrowed balance for this session
        uint256 startTime;
        Status status;
    }

    mapping(bytes32 => Session) public sessions;

    event Funded(bytes32 indexed sessionId, address indexed renter, address indexed host, uint256 amount, uint256 ratePerSecond);
    event Started(bytes32 indexed sessionId, uint256 startTime);
    event Closed(bytes32 indexed sessionId, uint256 paidToHost, uint256 refundedToRenter);
    event Slashed(bytes32 indexed sessionId, uint256 paidToRenter, uint256 paidToHost, uint256 bps);

    constructor(address platformOperator) Ownable(platformOperator) {}

    /// @notice Renter deposits funds for a session, identified by a hash
    /// of the off-chain request id (see relay-service for how the id is
    /// derived — it must match exactly what the relay-service hashes).
    function fundSession(bytes32 sessionId, address host, uint256 ratePerSecond) external payable {
        require(sessions[sessionId].status == Status.None, "session already exists");
        require(msg.value > 0, "must fund something");
        require(host != address(0), "host required");
        require(ratePerSecond > 0, "rate required");

        sessions[sessionId] = Session({
            renter: msg.sender,
            host: host,
            ratePerSecond: ratePerSecond,
            deposited: msg.value,
            startTime: 0,
            status: Status.Funded
        });

        emit Funded(sessionId, msg.sender, host, msg.value, ratePerSecond);
    }

    /// @notice Marks billing start. Called by the relay-service once the
    /// host has accepted the request (this is the Worker's "open_stream").
    function startSession(bytes32 sessionId) external onlyOwner {
        Session storage s = sessions[sessionId];
        require(s.status == Status.Funded, "not funded");
        s.startTime = block.timestamp;
        s.status = Status.Active;
        emit Started(sessionId, s.startTime);
    }

    /// @notice Settles the session: host gets elapsed*rate (capped at what
    /// was deposited), renter gets whatever's left. Called by the
    /// relay-service on session close ("close_stream").
    function closeSession(bytes32 sessionId) external onlyOwner nonReentrant {
        Session storage s = sessions[sessionId];
        require(s.status == Status.Active, "not active");

        uint256 elapsed = block.timestamp - s.startTime;
        uint256 owed = elapsed * s.ratePerSecond;
        if (owed > s.deposited) owed = s.deposited;
        uint256 refund = s.deposited - owed;

        s.status = Status.Closed;
        s.deposited = 0;

        if (owed > 0) {
            (bool sentHost, ) = s.host.call{value: owed}("");
            require(sentHost, "host payment failed");
        }
        if (refund > 0) {
            (bool sentRenter, ) = s.renter.call{value: refund}("");
            require(sentRenter, "refund failed");
        }

        emit Closed(sessionId, owed, refund);
    }

    /// @notice Redirects a percentage of whatever is still escrowed (not
    /// yet paid out) to the renter as compensation for a violation, pays
    /// the rest to the host, and closes the session. This slashes THIS
    /// session's escrow only — it is not a persistent host collateral
    /// pool. A host who repeatedly violates loses money session by
    /// session; a separate always-staked bond contract is a reasonable
    /// next step but isn't implemented here (see README).
    function slashAndClose(bytes32 sessionId, uint256 bps) external onlyOwner nonReentrant {
        require(bps <= 10000, "bps must be <= 10000");
        Session storage s = sessions[sessionId];
        require(s.status == Status.Active, "not active");

        uint256 toRenter = (s.deposited * bps) / 10000;
        uint256 toHost = s.deposited - toRenter;

        s.status = Status.Closed;
        s.deposited = 0;

        if (toRenter > 0) {
            (bool sentRenter, ) = s.renter.call{value: toRenter}("");
            require(sentRenter, "refund failed");
        }
        if (toHost > 0) {
            (bool sentHost, ) = s.host.call{value: toHost}("");
            require(sentHost, "host payment failed");
        }

        emit Slashed(sessionId, toRenter, toHost, bps);
    }

    function getSession(bytes32 sessionId) external view returns (Session memory) {
        return sessions[sessionId];
    }
}
