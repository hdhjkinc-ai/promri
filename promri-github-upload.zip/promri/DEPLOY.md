# Deploy, domain, money, and limits — the practical stuff

## 0. Deploying from a phone (no computer, no terminal)

You don't need `wrangler`/a terminal at all. Cloudflare's **Workers
Builds** connects a Worker straight to a GitHub repo and deploys on
every push, entirely through the dashboard (works fine in a mobile
browser):

1. Get this code into a GitHub repo. From a phone: the GitHub app (or
   github.com in your browser) lets you create a repo and upload files
   directly — no git CLI needed for a one-time upload.
2. In the Cloudflare dashboard → Workers & Pages → Create → **Import a
   Git repository** → pick that repo, point it at the `worker/`
   subfolder. Cloudflare builds and deploys it; every future push
   redeploys automatically.
3. D1: Workers & Pages → D1 → Create database, then D1 → your database →
   Console tab, paste the contents of `worker/schema.sql` and run it —
   this is a text box in the dashboard, no CLI.
4. Bind the D1 database to the Worker: your Worker's Settings →
   Bindings → add a D1 binding named `DB` pointing at that database.
5. Secrets/vars: your Worker's Settings → Variables and Secrets → add
   `EVM_RPC_URL`, `PLATFORM_PRIVATE_KEY` (mark as Secret, not plain
   text), `RELAY_API_KEY`, `ESCROW_CONTRACT_ADDRESS`, `EVM_CHAIN_ID`.
6. The website is just a static HTML file — GitHub Pages (Settings →
   Pages, in the same repo) will serve `website/index.html` with zero
   build step, also settable from the GitHub mobile web UI.

The one piece you can't do from a phone with zero setup: deploying the
smart contract needs `npx hardhat run` (see `contracts/README.md`),
which wants a real terminal. If you truly have no computer available,
this is the one step to borrow one for, or ask someone to run once —
after that, the address it prints is just a value you paste into the
dashboard like everything else above.

## 1. Deploy the Worker (if you do have a terminal)

```bash
cd worker
npm install
./deploy.sh
```

Walks you through `wrangler login` (opens a browser tab — your token
never gets pasted into a file), creates the D1 database, applies the
schema, offers to set your secrets, and deploys.

## 2. The money system — what actually moves funds, and where it runs

Three pieces, and only one of them needs anything beyond Cloudflare:

- **The Worker** (Cloudflare, your existing account) — runs the
  marketplace API and, via `worker/src/chain.js`, talks *directly* to
  the escrow contract using `viem` (a library built for edge runtimes
  like Workers — no separate server to host). This replaced an earlier,
  more complicated design that needed its own hosted relay service;
  it doesn't anymore.
- **The escrow contract** (`contracts/PromriEscrow.sol`) — a real,
  compiled Solidity contract. Deploy it once (see `contracts/README.md`)
  to any EVM chain. It holds a renter's deposit, and only the platform's
  own key (`PLATFORM_PRIVATE_KEY`) can start, close, or slash a session.
- **An RPC endpoint** (`EVM_RPC_URL`) — the one thing Cloudflare
  genuinely can't provide, because Cloudflare doesn't run blockchain
  nodes. For testing, a public testnet RPC needs no signup at all (Base
  Sepolia: `https://sepolia.base.org`) — see `contracts/README.md`.

Flow: consumer creates a request → their own wallet calls
`fundSession()` on the contract directly (via the website's built-in
`viem` wallet integration — their money, their signature, never passes
through the Worker) → host clicks Accept → the Worker checks the
contract confirms it's funded → if yes, the Worker calls `startSession()`
→ later, closing the session calls `closeSession()`, which pays the host
and refunds any unused deposit automatically.

**Honest limitation, stated plainly:** this settles at session-close
time (elapsed-seconds × rate), not by moving tokens every single second
on-chain — true continuous streaming is what Superfluid's own protocol
does, and integrating that is a separate, larger piece than writing one
contract. What's here gets you the same "pay for what ran" outcome
without needing to adopt an entire external payment protocol first.

## 3. Where to actually edit things

| Want to change... | File | What to edit |
|---|---|---|
| The API URL the site talks to | `website/index.html` | `const API = window.PROMRI_API_BASE \|\| "..."` |
| The escrow contract address the site funds against | `website/index.html` | `window.PROMRI_ESCROW_ADDRESS` (near the funding `<script type="module">` block) |
| Site title / tab text | `website/index.html` | `<title>` tag |
| Colors, fonts | `website/index.html` | the `:root { --bg: ...; }` block in `<style>` |
| Copy on the homepage | `website/index.html` | `<section class="hero">` and `.pillars` blocks |
| Which chain the Worker talks to | `worker/wrangler.toml` | `[vars] EVM_CHAIN_ID`, plus the `EVM_RPC_URL` secret |
| The escrow contract itself | `contracts/contracts/PromriEscrow.sol` | re-run `node compile.js` and redeploy after any change |
| D1 table structure | `worker/schema.sql` | add new migration files under `worker/migrations/` instead of editing deployed tables in place |
| API routes | `worker/src/index.js` | add an `else if` branch, point it at a handler in the matching `src/*.js` file |

## 4. Cloudflare free-tier limits (Sept 2026 — verify against your dashboard)

| Resource | Free tier limit |
|---|---|
| Workers requests | 100,000 / day, resets 00:00 UTC |
| Workers CPU time | 30ms per request |
| D1 row reads | 5,000,000 / day |
| D1 row writes | 100,000 / day |
| D1 storage | 5GB total |
| Pages builds | 500 / month |

**Concretely, what that means for accounts and purchases:** there's no
flat "max users" number — total *stored* rows are capped by the 5GB
storage limit, not by count. A host/consumer/resource row is a few
hundred bytes, so you'd fit low millions of them before storage runs
out. The number that actually limits you day-to-day is the **100,000
row writes/day** cap: every signup, request, message, or session
transition is one write. A single "purchase" (create request → fund →
accept → a few chat messages → close → feedback) is roughly 6-10 writes,
so free tier comfortably supports on the order of **10,000+ completed
transactions per day** before you'd hit the write ceiling — reads (5M/day)
aren't the binding constraint. Since September 1, 2026 Cloudflare
hard-enforces these limits on the free plan: go over and D1 queries fail
until UTC midnight resets them. Past that, D1's paid tier is
pay-per-row, not a hard wall.

## 5. What still needs a human, not code

- **Liability / privacy terms for file uploads or the contract's fund
  flow**: not included as binding legal language. Get an actual lawyer
  to review anything you tell users about liability — the disclaimer
  itself has jurisdiction-specific rules, and a wrong one can be
  unenforceable or worse than none.
- **Cloning/imaging a host's actual OS**: not built. Workloads run in a
  fresh Docker container on the host machine instead — the standard way
  this gets solved, rather than cloning+scanning a real system image.
- **Live-network testing of the contract**: verified to compile
  correctly (real bytecode, ABI checked against the Worker's calls) but
  not run against a live chain from here — do a testnet dry run (fund →
  accept → close → check both wallets' balances) before real money.
