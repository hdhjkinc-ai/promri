import { uuid } from "./util.js";
import { relayChainCall } from "./relay.js";

export async function submitAttestation({ host_id, resource_id, report }, env) {
  if (!host_id || !report) throw new Error("host_id and report are required");

  const id = uuid();
  await env.DB.prepare(
    `INSERT INTO attestations (id, host_id, resource_id, report_json, verified)
     VALUES (?, ?, ?, ?, 0)`
  ).bind(id, host_id, resource_id ?? null, JSON.stringify(report)).run();

  // Forward the raw on-device report to the oracle/validator set. The
  // Worker takes no position on whether the hardware is genuine — it
  // just carries the report there and writes back whatever the oracle
  // decides.
  const relayResult = await relayChainCall({
    target: "oracle",
    action: "attest",
    payload: { attestation_id: id, host_id, resource_id, report },
  }, env);

  const verified = relayResult.status === "ok" && relayResult.response?.verified === true;

  await env.DB.prepare(
    `UPDATE attestations SET verified = ?, oracle_ref = ? WHERE id = ?`
  ).bind(verified ? 1 : 0, relayResult.response?.oracle_ref ?? null, id).run();

  if (verified && resource_id) {
    await env.DB.prepare(
      `UPDATE resources SET status = 'available', hardware_attestation_id = ? WHERE id = ?`
    ).bind(id, resource_id).run();
  }

  return { attestation_id: id, verified, oracle_response: relayResult.response };
}
