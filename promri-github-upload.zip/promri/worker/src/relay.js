import { uuid } from "./util.js";
import * as chain from "./chain.js";
import { heuristicAttest } from "./attestation-heuristic.js";

/**
 * relayChainCall — same call shape as before (target/action/payload), so
 * everything that calls this didn't need to change. What's different:
 * it no longer forwards to an external HTTP server. 'chain_rpc' actions
 * go straight to the PromriEscrow contract via chain.js (viem); 'oracle'
 * goes to the in-Worker heuristic. Everything's still logged to
 * relay_log for auditability either way.
 */
export async function relayChainCall(body, env) {
  const { target, session_id = null, action, payload = {} } = body;
  if (!target || !action) throw new Error("target and action are required");

  let responseBody, status = "ok";
  try {
    if (target === "chain_rpc") {
      responseBody = await dispatchChain(action, payload, env);
    } else if (target === "oracle") {
      responseBody = heuristicAttest(payload);
    } else {
      throw new Error(`unknown relay target '${target}'`);
    }
  } catch (err) {
    responseBody = { error: err.message };
    status = "error";
  }

  await env.DB.prepare(
    `INSERT INTO relay_log (id, session_id, action, chain, request_json, response_json, status)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    uuid(), session_id, action, payload?.chain ?? null,
    JSON.stringify(payload ?? {}), JSON.stringify(responseBody), status
  ).run();

  return { status, response: responseBody };
}

async function dispatchChain(action, payload, env) {
  switch (action) {
    case "check_escrow": return await chain.checkEscrow(payload, env);
    case "open_stream": return await chain.openStream(payload, env);
    case "close_stream": return await chain.closeStream(payload, env);
    case "slash": return await chain.slash(payload, env);
    default: throw new Error(`unknown chain action '${action}'`);
  }
}
