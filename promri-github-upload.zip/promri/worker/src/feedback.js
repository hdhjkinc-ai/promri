import { uuid } from "./util.js";

export async function submitFeedback({ session_id, from_role, from_id, to_id, rating, comment }, env) {
  if (!session_id || !from_role || !from_id || !to_id || !rating) {
    throw new Error("session_id, from_role, from_id, to_id, and rating are required");
  }
  if (rating < 1 || rating > 5) throw new Error("rating must be between 1 and 5");

  const session = await env.DB.prepare(`SELECT * FROM sessions WHERE id = ?`).bind(session_id).first();
  if (!session) throw new Error("unknown session_id");
  if (session.status !== "completed") throw new Error("feedback can only be left after a session completes");

  const id = uuid();
  await env.DB.prepare(
    `INSERT INTO feedback (id, session_id, from_role, from_id, to_id, rating, comment)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(id, session_id, from_role, from_id, to_id, rating, comment ?? null).run();

  // Reputation is a simple rolling average against the target's history —
  // hosts and consumers share the same feedback table, only hosts carry
  // a visible reputation_score today since the marketplace listing sorts by it.
  const target = await env.DB.prepare(`SELECT id FROM hosts WHERE id = ?`).bind(to_id).first();
  if (target) {
    const { avg } = await env.DB.prepare(
      `SELECT AVG(rating) as avg FROM feedback WHERE to_id = ?`
    ).bind(to_id).first();
    // Blend into a 0-100 score so it sorts alongside the default of 100 for new hosts.
    const score = Math.round((avg / 5) * 100);
    await env.DB.prepare(`UPDATE hosts SET reputation_score = ? WHERE id = ?`).bind(score, to_id).run();
  }

  return await env.DB.prepare(`SELECT * FROM feedback WHERE id = ?`).bind(id).first();
}

export async function listFeedbackFor(targetId, env) {
  const { results } = await env.DB.prepare(
    `SELECT * FROM feedback WHERE to_id = ? ORDER BY created_at DESC LIMIT 50`
  ).bind(targetId).all();
  return { feedback: results };
}
