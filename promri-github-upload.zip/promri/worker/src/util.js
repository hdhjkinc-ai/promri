export function json(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...headers },
  });
}

export function notFound(headers = {}) {
  return json({ error: "not_found" }, 404, headers);
}

export function badRequest(message, headers = {}) {
  return json({ error: "bad_request", message }, 400, headers);
}

export function unauthorized(headers = {}) {
  return json({ error: "unauthorized" }, 401, headers);
}

export function uuid() {
  return crypto.randomUUID();
}
