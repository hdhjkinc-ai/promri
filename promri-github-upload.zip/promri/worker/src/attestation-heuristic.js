/**
 * Runs entirely inside the Worker — no external oracle server required.
 *
 * Be clear about what this is and isn't: a bounds/plausibility check on
 * the numbers the host's desktop app reported (is 128 cores on a
 * consumer CPU model plausible? is claimed RAM within sane limits?).
 * It is NOT cryptographic proof of hardware identity — that requires an
 * actual TPM quote verified against real silicon, which can't be done
 * from a self-reported JSON blob alone, in a Worker or anywhere else.
 * Treat this as spam/nonsense filtering, not fraud-proofing. A real
 * Proof-of-Hardware validator set (per the original spec) is a
 * meaningfully larger, separate build.
 */
const PLAUSIBLE = {
  cpu_cores: { min: 1, max: 512 },
  ram_gb: { min: 1, max: 8192 },
};

export function heuristicAttest({ report }) {
  const issues = [];
  const cores = Number(report?.cpu_cores);
  const ram = Number(report?.ram_gb);

  if (!Number.isFinite(cores) || cores < PLAUSIBLE.cpu_cores.min || cores > PLAUSIBLE.cpu_cores.max) {
    issues.push(`cpu_cores (${report?.cpu_cores}) is out of plausible range`);
  }
  if (!Number.isFinite(ram) || ram < PLAUSIBLE.ram_gb.min || ram > PLAUSIBLE.ram_gb.max) {
    issues.push(`ram_gb (${report?.ram_gb}) is out of plausible range`);
  }
  if (!report?.cpu_model) issues.push("cpu_model missing");
  if (!report?.platform) issues.push("platform missing");

  return {
    verified: issues.length === 0,
    issues,
    oracle_ref: `heuristic:${Date.now()}`,
  };
}
