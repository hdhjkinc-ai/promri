import { uuid } from "./util.js";

export async function registerConsumer({ wallet_address, display_name, contact_email, contact_phone }, env) {
  if (!wallet_address) throw new Error("wallet_address is required");
  const id = uuid();
  await env.DB.prepare(
    `INSERT INTO consumers (id, wallet_address, display_name, contact_email, contact_phone)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(wallet_address) DO UPDATE SET
       display_name = excluded.display_name,
       contact_email = excluded.contact_email,
       contact_phone = excluded.contact_phone`
  ).bind(id, wallet_address, display_name ?? null, contact_email ?? null, contact_phone ?? null).run();

  return await env.DB.prepare(`SELECT * FROM consumers WHERE wallet_address = ?`)
    .bind(wallet_address).first();
}
