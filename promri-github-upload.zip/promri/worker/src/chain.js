/**
 * chain.js — the Worker talks to the PromriEscrow contract directly,
 * using viem (built for edge runtimes like Cloudflare Workers, unlike
 * ethers.js which assumes a Node environment). No separate server to
 * host: this runs as part of the same Worker that already serves the
 * marketplace API.
 *
 * What you still need, unavoidably: an actual EVM RPC endpoint URL
 * (`env.EVM_RPC_URL`) — Cloudflare doesn't run blockchain nodes itself.
 * For getting started with zero signups, public testnet RPCs work with
 * no API key (e.g. Base Sepolia: https://sepolia.base.org) — see
 * DEPLOY.md. For real money later, swap in a paid provider's URL; the
 * code here doesn't change either way.
 *
 * env vars used:
 *   EVM_RPC_URL           - the chain RPC endpoint (secret)
 *   PLATFORM_PRIVATE_KEY  - the platform's signer key, owns the contract (secret)
 *   ESCROW_CONTRACT_ADDRESS - deployed PromriEscrow address (plain var, not secret — it's public)
 *   EVM_CHAIN_ID          - numeric chain id (plain var, defaults to Base Sepolia's 84532)
 */
import {
  createPublicClient,
  createWalletClient,
  http,
  keccak256,
  toBytes,
  defineChain,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";

const ABI = [
  {
    type: "function", name: "fundSession", stateMutability: "payable",
    inputs: [{ name: "sessionId", type: "bytes32" }, { name: "host", type: "address" }, { name: "ratePerSecond", type: "uint256" }],
    outputs: [],
  },
  {
    type: "function", name: "startSession", stateMutability: "nonpayable",
    inputs: [{ name: "sessionId", type: "bytes32" }], outputs: [],
  },
  {
    type: "function", name: "closeSession", stateMutability: "nonpayable",
    inputs: [{ name: "sessionId", type: "bytes32" }], outputs: [],
  },
  {
    type: "function", name: "slashAndClose", stateMutability: "nonpayable",
    inputs: [{ name: "sessionId", type: "bytes32" }, { name: "bps", type: "uint256" }], outputs: [],
  },
  {
    type: "function", name: "getSession", stateMutability: "view",
    inputs: [{ name: "sessionId", type: "bytes32" }],
    outputs: [{
      type: "tuple", components: [
        { name: "renter", type: "address" }, { name: "host", type: "address" },
        { name: "ratePerSecond", type: "uint256" }, { name: "deposited", type: "uint256" },
        { name: "startTime", type: "uint256" }, { name: "status", type: "uint8" },
      ],
    }],
  },
];

/// The bytes32 key both the front-end (when funding) and this Worker
/// (when reading/starting/closing) must derive identically from a
/// request id string — a plain keccak256 of its UTF-8 bytes.
export function sessionKeyFromRequestId(requestId) {
  return keccak256(toBytes(requestId));
}

function getChain(env) {
  return defineChain({
    id: Number(env.EVM_CHAIN_ID || 84532), // Base Sepolia by default
    name: "promri-configured-chain",
    nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 },
    rpcUrls: { default: { http: [env.EVM_RPC_URL] } },
  });
}

function clients(env) {
  if (!env.EVM_RPC_URL) throw new Error("EVM_RPC_URL is not configured");
  if (!env.PLATFORM_PRIVATE_KEY) throw new Error("PLATFORM_PRIVATE_KEY is not configured");
  if (!env.ESCROW_CONTRACT_ADDRESS) throw new Error("ESCROW_CONTRACT_ADDRESS is not configured");

  const chain = getChain(env);
  const transport = http(env.EVM_RPC_URL);
  const account = privateKeyToAccount(env.PLATFORM_PRIVATE_KEY);
  const publicClient = createPublicClient({ chain, transport });
  const walletClient = createWalletClient({ chain, transport, account });
  return { publicClient, walletClient, account, contract: env.ESCROW_CONTRACT_ADDRESS };
}

const STATUS = ["None", "Funded", "Active", "Closed"];

export async function checkEscrow({ request_id }, env) {
  const { publicClient, contract } = clients(env);
  const key = sessionKeyFromRequestId(request_id);
  const session = await publicClient.readContract({
    address: contract, abi: ABI, functionName: "getSession", args: [key],
  });
  const status = STATUS[session.status] ?? "Unknown";
  return {
    funded: status === "Funded" || status === "Active",
    status,
    deposited: session.deposited.toString(),
    session_key: key,
  };
}

export async function openStream({ request_id }, env) {
  const { publicClient, walletClient, account, contract } = clients(env);
  const key = sessionKeyFromRequestId(request_id);
  const hash = await walletClient.writeContract({
    address: contract, abi: ABI, functionName: "startSession", args: [key], account,
  });
  await publicClient.waitForTransactionReceipt({ hash });
  return { stream_id: key, tx_hash: hash };
}

export async function closeStream({ stream_id }, env) {
  const { publicClient, walletClient, account, contract } = clients(env);
  const hash = await walletClient.writeContract({
    address: contract, abi: ABI, functionName: "closeSession", args: [stream_id], account,
  });
  await publicClient.waitForTransactionReceipt({ hash });
  return { tx_hash: hash };
}

export async function slash({ stream_id, bps }, env) {
  const { publicClient, walletClient, account, contract } = clients(env);
  const hash = await walletClient.writeContract({
    address: contract, abi: ABI, functionName: "slashAndClose", args: [stream_id, BigInt(bps ?? 5000)], account,
  });
  await publicClient.waitForTransactionReceipt({ hash });
  return { tx_hash: hash, bps: bps ?? 5000 };
}
