import { uuid } from "./util.js";
import { relayChainCall } from "./relay.js";

export async function createSession({ resource_id, consumer_id, chain, request_id }, env) {
  const resource = await env.DB.prepare(`SELECT * FROM resources WHERE id = ?`).bind(resource_id).first();
  if (!resource) throw new Error("unknown resource_id");
  if (resource.status !== "available") throw new Error(`resource is not available (status: ${resource.status})`);

  const host = await env.DB.prepare(`SELECT * FROM hosts WHERE id = ?`).bind(resource.host_id).first();
  if (host.status !== "active") throw new Error(`host is currently ${host.status} and cannot take new sessions`);

  const consumer = await env.DB.prepare(`SELECT * FROM consumers WHERE id = ?`).bind(consumer_id).first();
  if (!consumer) throw new Error("unknown consumer_id");
  if (consumer.status !== "active") throw new Error(`consumer account is currently ${consumer.status}`);
  if (!request_id) throw new Error("request_id is required — a session only ever comes from an accepted request");

  const id = uuid();

  // Tell the contract billing starts now. The on-chain key is derived
  // from request_id — the same id the consumer's wallet funded escrow
  // against before the host ever saw this request — not this new DB
  // session id, which didn't exist yet at funding time.
  const relayResult = await relayChainCall({
    target: "chain_rpc",
    session_id: id,
    action: "open_stream",
    payload: { request_id, chain },
  }, env);

  if (relayResult.status !== "ok") {
    throw new Error(`could not open payment stream: ${JSON.stringify(relayResult.response)}`);
  }

  const stream_id = relayResult.response.stream_id ?? null;

  await env.DB.batch([
    env.DB.prepare(
      `INSERT INTO sessions (id, resource_id, host_id, consumer_id, status, chain, stream_id, price_per_hour, started_at)
       VALUES (?, ?, ?, ?, 'active', ?, ?, ?, datetime('now'))`
    ).bind(id, resource_id, resource.host_id, consumer_id, chain ?? null, stream_id, resource.price_per_hour),
    env.DB.prepare(`UPDATE resources SET status = 'in_session' WHERE id = ?`).bind(resource_id),
  ]);

  return await getSession(id, env);
}

export async function getSession(id, env) {
  const session = await env.DB.prepare(`SELECT * FROM sessions WHERE id = ?`).bind(id).first();
  if (!session) throw new Error("unknown session_id");
  return session;
}

export async function closeSession(id, { reason = "renter_end" }, env) {
  const session = await env.DB.prepare(`SELECT * FROM sessions WHERE id = ?`).bind(id).first();
  if (!session) throw new Error("unknown session_id");
  if (session.status !== "active") throw new Error(`session is not active (status: ${session.status})`);

  // Stopping the stream is the actual billing cutoff — this must happen
  // before we mark the session closed, so the renter is never charged
  // past the moment they (or the enforcement layer) called this.
  const relayResult = await relayChainCall({
    target: "chain_rpc",
    session_id: id,
    action: "close_stream",
    payload: { stream_id: session.stream_id, chain: session.chain },
  }, env);

  await env.DB.batch([
    env.DB.prepare(
      `UPDATE sessions SET status = 'completed', ended_at = datetime('now'), termination_reason = ? WHERE id = ?`
    ).bind(reason, id),
    env.DB.prepare(`UPDATE resources SET status = 'available' WHERE id = ?`).bind(session.resource_id),
  ]);

  return { session_id: id, stream_close: relayResult };
}

export async function reportViolation(sessionId, { violation_type, evidence, bps }, env) {
  const session = await env.DB.prepare(`SELECT * FROM sessions WHERE id = ?`).bind(sessionId).first();
  if (!session) throw new Error("unknown session_id");
  if (!violation_type) throw new Error("violation_type is required");

  // Tiered response, matching the spec: some violations end the session
  // immediately, all of them get logged as slashing evidence for the
  // relay to forward on-chain.
  const instantTerminate = ["unauthorized_process", "monitoring_disabled"].includes(violation_type);
  const instantBan = violation_type === "monitoring_disabled"; // spec: disabling monitoring = immediate permanent ban

  const id = uuid();
  await env.DB.prepare(
    `INSERT INTO violations (id, session_id, violation_type, evidence_json, action_taken)
     VALUES (?, ?, ?, ?, ?)`
  ).bind(id, sessionId, violation_type, JSON.stringify(evidence ?? {}),
    instantTerminate ? "session_terminated" : "flagged").run();

  // Suspension tiers: repeated or minor offenses -> temporary ban,
  // severe/repeated -> permanent. This is the "how many strikes" logic —
  // adjust the thresholds to whatever your rules doc actually says.
  const { strike_count } = await env.DB.prepare(
    `SELECT strike_count FROM hosts WHERE id = ?`
  ).bind(session.host_id).first();
  const newStrikes = strike_count + 1;

  let newStatus = null;
  if (instantBan || newStrikes >= 5) newStatus = "banned";
  else if (newStrikes >= 3) newStatus = "temp_banned";

  await env.DB.prepare(
    `UPDATE hosts SET strike_count = ?${newStatus ? ", status = ?" : ""} WHERE id = ?`
  ).bind(...(newStatus ? [newStrikes, newStatus, session.host_id] : [newStrikes, session.host_id])).run();

  let relayResult = null;
  if (instantTerminate) {
    // The contract's slashAndClose settles AND closes the session
    // on-chain in one call — there's no "slash but keep running" on the
    // contract, so this is the only chain call for a terminating
    // violation. Doing this instead of a separate close_stream call
    // avoids trying to close an already-closed on-chain session.
    relayResult = await relayChainCall({
      target: "chain_rpc",
      session_id: sessionId,
      action: "slash",
      payload: { stream_id: session.stream_id, bps: bps ?? 5000, violation_type, host_id: session.host_id },
    }, env);

    await env.DB.batch([
      env.DB.prepare(
        `UPDATE sessions SET status = 'completed', ended_at = datetime('now'), termination_reason = ? WHERE id = ?`
      ).bind(`violation:${violation_type}`, sessionId),
      env.DB.prepare(`UPDATE resources SET status = 'available' WHERE id = ?`).bind(session.resource_id),
    ]);
  }
  // A flagged (non-terminating) violation stays logged only — the
  // contract has no partial/non-closing slash, so no chain call happens
  // here. It still counts toward the host's strike total above.

  return { violation_id: id, terminated: instantTerminate, host_status: newStatus, relay: relayResult };
}
