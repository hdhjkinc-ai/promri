import { uuid } from "./util.js";

export async function registerHost({ wallet_address, display_name, contact_email, contact_phone, host_type }, env) {
  if (!wallet_address) throw new Error("wallet_address is required");
  if (host_type && !["individual", "enterprise"].includes(host_type)) {
    throw new Error("host_type must be 'individual' or 'enterprise'");
  }
  const id = uuid();
  await env.DB.prepare(
    `INSERT INTO hosts (id, wallet_address, display_name, contact_email, contact_phone, host_type)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(wallet_address) DO UPDATE SET
       display_name = excluded.display_name,
       contact_email = excluded.contact_email,
       contact_phone = excluded.contact_phone,
       host_type = excluded.host_type`
  ).bind(id, wallet_address, display_name ?? null, contact_email ?? null, contact_phone ?? null, host_type ?? "individual").run();

  const row = await env.DB.prepare(`SELECT * FROM hosts WHERE wallet_address = ?`)
    .bind(wallet_address).first();
  return row;
}

// --- Facilities: only meaningful for host_type = 'enterprise'. A company
// running multiple actual datacenters registers each site once, states
// its real total capacity, and decides what percentage of that capacity
// it's willing to commit to the marketplace — the rest stays off-platform.
export async function addFacility(hostId, { name, location, total_cpu_cores, total_ram_gb, total_gpu_count, gpu_model, allocated_percentage }, env) {
  const host = await env.DB.prepare(`SELECT * FROM hosts WHERE id = ?`).bind(hostId).first();
  if (!host) throw new Error("unknown host_id");
  if (host.host_type !== "enterprise") {
    throw new Error("facilities are only for enterprise hosts — set host_type to 'enterprise' when registering");
  }
  if (!name) throw new Error("name is required");
  const pct = allocated_percentage == null ? 100 : Number(allocated_percentage);
  if (pct <= 0 || pct > 100) throw new Error("allocated_percentage must be between 0 and 100");

  const id = uuid();
  await env.DB.prepare(
    `INSERT INTO facilities (id, host_id, name, location, total_cpu_cores, total_ram_gb, total_gpu_count, gpu_model, allocated_percentage)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(id, hostId, name, location ?? null, total_cpu_cores ?? null, total_ram_gb ?? null, total_gpu_count ?? null, gpu_model ?? null, pct).run();

  return await env.DB.prepare(`SELECT * FROM facilities WHERE id = ?`).bind(id).first();
}

export async function listFacilities(hostId, env) {
  const { results } = await env.DB.prepare(
    `SELECT * FROM facilities WHERE host_id = ? ORDER BY created_at DESC`
  ).bind(hostId).all();
  return { facilities: results };
}

export async function listPlatformTemplates(env) {
  const { results } = await env.DB.prepare(`SELECT * FROM platform_templates ORDER BY name`).all();
  return { templates: results };
}

export async function addResource(hostId, body, env) {
  const { cpu_cores, ram_gb, gpu_model, bandwidth_gb, price_per_hour, facility_id, service_model, platform_template_id } = body;
  if (!price_per_hour) throw new Error("price_per_hour is required");

  const host = await env.DB.prepare(`SELECT * FROM hosts WHERE id = ?`).bind(hostId).first();
  if (!host) throw new Error("unknown host_id");

  const model = service_model ?? "iaas";
  if (!["iaas", "paas"].includes(model)) throw new Error("service_model must be 'iaas' or 'paas'");
  if (model === "paas" && !platform_template_id) {
    throw new Error("platform_template_id is required for a PaaS resource — the renter never gets raw Docker access on this tier");
  }

  if (facility_id) {
    const facility = await env.DB.prepare(`SELECT * FROM facilities WHERE id = ? AND host_id = ?`)
      .bind(facility_id, hostId).first();
    if (!facility) throw new Error("unknown facility_id for this host");
  }

  const id = uuid();
  // New resources start in 'holding' — reserved/discoverable but not yet
  // runnable until hardware attestation clears it to 'available'.
  await env.DB.prepare(
    `INSERT INTO resources (id, host_id, facility_id, cpu_cores, ram_gb, gpu_model, bandwidth_gb, price_per_hour, status, service_model, platform_template_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'holding', ?, ?)`
  ).bind(id, hostId, facility_id ?? null, cpu_cores ?? null, ram_gb ?? null, gpu_model ?? null,
    bandwidth_gb ?? null, price_per_hour, model, platform_template_id ?? null).run();

  return await env.DB.prepare(`SELECT * FROM resources WHERE id = ?`).bind(id).first();
}

export async function listResources(params, env) {
  const status = params.get("status") ?? "available";
  const maxPrice = params.get("max_price");
  const minRam = params.get("min_ram_gb");
  const serviceModel = params.get("service_model"); // 'iaas' | 'paas', optional

  let q = `SELECT r.*, h.display_name as host_name, h.reputation_score, h.host_type
           FROM resources r JOIN hosts h ON h.id = r.host_id
           WHERE r.status = ?`;
  const bind = [status];

  if (maxPrice) { q += ` AND r.price_per_hour <= ?`; bind.push(Number(maxPrice)); }
  if (minRam) { q += ` AND r.ram_gb >= ?`; bind.push(Number(minRam)); }
  if (serviceModel) { q += ` AND r.service_model = ?`; bind.push(serviceModel); }
  q += ` ORDER BY h.reputation_score DESC, r.price_per_hour ASC LIMIT 100`;

  const { results } = await env.DB.prepare(q).bind(...bind).all();
  return { resources: results };
}

export async function getHostProfile(hostId, env) {
  const host = await env.DB.prepare(`SELECT * FROM hosts WHERE id = ?`).bind(hostId).first();
  if (!host) throw new Error("unknown host_id");

  const { results: resources } = await env.DB.prepare(
    `SELECT * FROM resources WHERE host_id = ?`
  ).bind(hostId).all();

  const { results: facilities } = host.host_type === "enterprise"
    ? await env.DB.prepare(`SELECT * FROM facilities WHERE host_id = ?`).bind(hostId).all()
    : { results: [] };

  const { results: reviews } = await env.DB.prepare(
    `SELECT rating, comment, created_at FROM feedback WHERE to_id = ? ORDER BY created_at DESC LIMIT 20`
  ).bind(hostId).all();

  return { ...host, resources, facilities, reviews };
}
