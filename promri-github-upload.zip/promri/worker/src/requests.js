import { uuid } from "./util.js";
import { relayChainCall } from "./relay.js";
import { createSession } from "./sessions.js";

export async function createRequest({ resource_id, consumer_id, chain, escrow_contract_address, share_contact }, env) {
  const resource = await env.DB.prepare(`SELECT * FROM resources WHERE id = ?`).bind(resource_id).first();
  if (!resource) throw new Error("unknown resource_id");
  if (resource.status !== "available") throw new Error(`resource is not available (status: ${resource.status})`);

  const consumer = await env.DB.prepare(`SELECT * FROM consumers WHERE id = ?`).bind(consumer_id).first();
  if (!consumer) throw new Error("unknown consumer_id");
  if (consumer.status !== "active") throw new Error(`your account is currently ${consumer.status} and can't send new requests`);

  const id = uuid();
  await env.DB.batch([
    env.DB.prepare(
      `INSERT INTO session_requests (id, resource_id, host_id, consumer_id, chain, escrow_contract_address, share_contact)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).bind(id, resource_id, resource.host_id, consumer_id, chain ?? null, escrow_contract_address ?? null, share_contact ? 1 : 0),
    // Hold the resource out of listings while a decision is pending, same
    // idea as the spec's "holding" state — just for a request instead of a session.
    env.DB.prepare(`UPDATE resources SET status = 'requested' WHERE id = ?`).bind(resource_id),
  ]);

  return await env.DB.prepare(`SELECT * FROM session_requests WHERE id = ?`).bind(id).first();
}

export async function listRequestsForHost(hostId, env) {
  const { results } = await env.DB.prepare(
    `SELECT sr.*, c.display_name as consumer_name, r.cpu_cores, r.ram_gb, r.gpu_model, r.price_per_hour
     FROM session_requests sr
     JOIN consumers c ON c.id = sr.consumer_id
     JOIN resources r ON r.id = sr.resource_id
     WHERE sr.host_id = ? AND sr.status = 'pending'
     ORDER BY sr.created_at DESC`
  ).bind(hostId).all();
  return { requests: results };
}

export async function declineRequest(requestId, env) {
  const req = await env.DB.prepare(`SELECT * FROM session_requests WHERE id = ?`).bind(requestId).first();
  if (!req) throw new Error("unknown request_id");
  if (req.status !== "pending") throw new Error(`request is not pending (status: ${req.status})`);

  await env.DB.batch([
    env.DB.prepare(`UPDATE session_requests SET status = 'declined', responded_at = datetime('now') WHERE id = ?`).bind(requestId),
    env.DB.prepare(`UPDATE resources SET status = 'available' WHERE id = ?`).bind(req.resource_id),
  ]);
  return { request_id: requestId, status: "declined" };
}

/**
 * acceptRequest — the accountability gate. A host saying "yes" here is a
 * commitment to actually run the workload, so before anything is
 * confirmed we ask the relay whether the renter's escrow is really
 * funded. If it isn't (or the check fails), we refuse to accept and tell
 * the host why, rather than silently trusting a "yes" click.
 */
export async function acceptRequest(requestId, env) {
  const req = await env.DB.prepare(`SELECT * FROM session_requests WHERE id = ?`).bind(requestId).first();
  if (!req) throw new Error("unknown request_id");
  if (req.status !== "pending") throw new Error(`request is not pending (status: ${req.status})`);

  const escrowCheck = await relayChainCall({
    target: "chain_rpc",
    action: "check_escrow",
    payload: { request_id: requestId, chain: req.chain },
  }, env);

  const funded = escrowCheck.status === "ok" && escrowCheck.response?.funded === true;

  if (!funded) {
    // This is the consumer's side of accountability: repeatedly sending
    // requests without funding escrow costs hosts real time. Strike it
    // the same way a host's violations are tiered.
    const { strike_count } = await env.DB.prepare(
      `SELECT strike_count FROM consumers WHERE id = ?`
    ).bind(req.consumer_id).first();
    const newStrikes = strike_count + 1;
    let newStatus = null;
    if (newStrikes >= 5) newStatus = "suspended";
    else if (newStrikes >= 3) newStatus = "temp_suspended";
    await env.DB.prepare(
      `UPDATE consumers SET strike_count = ?${newStatus ? ", status = ?" : ""} WHERE id = ?`
    ).bind(...(newStatus ? [newStrikes, newStatus, req.consumer_id] : [newStrikes, req.consumer_id])).run();

    return {
      ok: false,
      request_id: requestId,
      warning:
        "This renter's payment is not confirmed as funded yet. Do not accept — starting a session " +
        "now means running real work with no guarantee you'll be paid for it. Wait until escrow shows " +
        "as funded, then try accepting again.",
      escrow_status: escrowCheck.response,
    };
  }

  const session = await createSession({
    resource_id: req.resource_id,
    consumer_id: req.consumer_id,
    chain: req.chain,
    request_id: requestId,
  }, env);

  await env.DB.prepare(
    `UPDATE session_requests SET status = 'accepted', responded_at = datetime('now'), session_id = ? WHERE id = ?`
  ).bind(session.id, requestId).run();

  let sharedContact = null;
  if (req.share_contact) {
    const [host, consumer] = await Promise.all([
      env.DB.prepare(`SELECT contact_email, contact_phone FROM hosts WHERE id = ?`).bind(req.host_id).first(),
      env.DB.prepare(`SELECT contact_email, contact_phone FROM consumers WHERE id = ?`).bind(req.consumer_id).first(),
    ]);
    sharedContact = { host_contact: host, consumer_contact: consumer };
  }

  return { ok: true, request_id: requestId, session, shared_contact: sharedContact };
}
