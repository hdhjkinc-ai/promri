/**
 * PROMRI marketplace Worker.
 *
 * Scope, deliberately: this Worker owns marketplace state in D1 (hosts,
 * resources, sessions, feedback, attestations) and acts as a thin RELAY
 * to an external chain RPC + oracle for anything money- or
 * hardware-trust related. It never holds funds, never runs eBPF/TPM
 * checks itself, and never executes rented workloads — those happen on
 * the host's machine via the desktop app, and settlement happens on
 * whatever chain is configured.
 *
 * Bindings expected (wrangler.toml):
 *   DB              - D1 database
 *   CHAIN_RPC_URL   - secret, e.g. an Alchemy/Infura endpoint
 *   ORACLE_URL      - secret, attestation/oracle service endpoint
 *   RELAY_API_KEY   - secret, shared key the desktop app + website use
 */

import { json, notFound, badRequest, unauthorized, uuid } from "./util.js";
import { registerHost, listResources, addResource, getHostProfile, addFacility, listFacilities, listPlatformTemplates } from "./hosts.js";
import { registerConsumer } from "./consumers.js";
import { createSession, closeSession, getSession, reportViolation } from "./sessions.js";
import { createRequest, listRequestsForHost, acceptRequest, declineRequest } from "./requests.js";
import { sendMessage, listMessages } from "./messages.js";
import { submitAttestation } from "./attestation.js";
import { relayChainCall } from "./relay.js";
import { submitFeedback, listFeedbackFor } from "./feedback.js";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const { pathname } = url;
    const method = request.method;

    // CORS for the website + desktop app calling from anywhere
    if (method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders() });
    }

    try {
      let res;

      // --- Hosts ---------------------------------------------------
      if (pathname === "/api/hosts/register" && method === "POST") {
        res = await registerHost(await request.json(), env);
      } else if (pathname.match(/^\/api\/hosts\/[^/]+$/) && method === "GET") {
        const id = pathname.split("/")[3];
        res = await getHostProfile(id, env);

      // --- Consumers -------------------------------------------------
      } else if (pathname === "/api/consumers/register" && method === "POST") {
        res = await registerConsumer(await request.json(), env);

      // --- Resources -------------------------------------------------
      } else if (pathname === "/api/resources" && method === "GET") {
        res = await listResources(url.searchParams, env);
      } else if (pathname.match(/^\/api\/hosts\/[^/]+\/resources$/) && method === "POST") {
        const hostId = pathname.split("/")[3];
        res = await addResource(hostId, await request.json(), env);

      // --- Enterprise facilities (host_type = 'enterprise' only) -------
      } else if (pathname.match(/^\/api\/hosts\/[^/]+\/facilities$/) && method === "POST") {
        const hostId = pathname.split("/")[3];
        res = await addFacility(hostId, await request.json(), env);
      } else if (pathname.match(/^\/api\/hosts\/[^/]+\/facilities$/) && method === "GET") {
        const hostId = pathname.split("/")[3];
        res = await listFacilities(hostId, env);

      // --- PaaS templates ------------------------------------------------
      } else if (pathname === "/api/platform-templates" && method === "GET") {
        res = await listPlatformTemplates(env);

      // --- Attestation (host app -> Worker -> oracle) -----------------
      } else if (pathname === "/api/attestations" && method === "POST") {
        res = await submitAttestation(await request.json(), env);

      // --- Requests (host must accept/decline before a session opens) --
      } else if (pathname === "/api/requests" && method === "POST") {
        res = await createRequest(await request.json(), env);
      } else if (pathname.match(/^\/api\/requests\/host\/[^/]+$/) && method === "GET") {
        const hostId = pathname.split("/")[4];
        res = await listRequestsForHost(hostId, env);
      } else if (pathname.match(/^\/api\/requests\/[^/]+\/accept$/) && method === "POST") {
        const id = pathname.split("/")[3];
        res = await acceptRequest(id, env);
      } else if (pathname.match(/^\/api\/requests\/[^/]+\/decline$/) && method === "POST") {
        const id = pathname.split("/")[3];
        res = await declineRequest(id, env);

      // --- Pre-transaction chat, scoped to a request -------------------
      } else if (pathname.match(/^\/api\/requests\/[^/]+\/messages$/) && method === "POST") {
        const id = pathname.split("/")[3];
        res = await sendMessage({ request_id: id, ...(await request.json()) }, env);
      } else if (pathname.match(/^\/api\/requests\/[^/]+\/messages$/) && method === "GET") {
        const id = pathname.split("/")[3];
        res = await listMessages(id, env);

      // --- Sessions ----------------------------------------------------
      } else if (pathname === "/api/sessions" && method === "POST") {
        res = await createSession(await request.json(), env);
      } else if (pathname.match(/^\/api\/sessions\/[^/]+$/) && method === "GET") {
        const id = pathname.split("/")[3];
        res = await getSession(id, env);
      } else if (pathname.match(/^\/api\/sessions\/[^/]+\/close$/) && method === "POST") {
        const id = pathname.split("/")[3];
        res = await closeSession(id, await request.json(), env);
      } else if (pathname.match(/^\/api\/sessions\/[^/]+\/violations$/) && method === "POST") {
        const id = pathname.split("/")[3];
        res = await reportViolation(id, await request.json(), env);

      // --- Feedback (e-commerce style reviews) ------------------------
      } else if (pathname === "/api/feedback" && method === "POST") {
        res = await submitFeedback(await request.json(), env);
      } else if (pathname.match(/^\/api\/feedback\/[^/]+$/) && method === "GET") {
        const id = pathname.split("/")[3];
        res = await listFeedbackFor(id, env);

      // --- Raw relay passthrough (host app asking Worker to check a
      //     chain state or ping the oracle; Worker never signs anything) --
      } else if (pathname === "/api/relay" && method === "POST") {
        const key = request.headers.get("x-relay-key");
        if (key !== env.RELAY_API_KEY) return unauthorized();
        res = await relayChainCall(await request.json(), env);

      } else {
        return notFound();
      }

      return json(res, 200, corsHeaders());
    } catch (err) {
      return badRequest(err.message ?? "bad request", corsHeaders());
    }
  },
};

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, x-relay-key",
  };
}
