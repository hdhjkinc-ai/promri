import { uuid } from "./util.js";

export async function sendMessage({ request_id, from_role, body }, env) {
  if (!request_id || !from_role || !body) throw new Error("request_id, from_role, and body are required");
  if (!["host", "consumer"].includes(from_role)) throw new Error("from_role must be 'host' or 'consumer'");

  const req = await env.DB.prepare(`SELECT id FROM session_requests WHERE id = ?`).bind(request_id).first();
  if (!req) throw new Error("unknown request_id");

  const id = uuid();
  await env.DB.prepare(
    `INSERT INTO messages (id, request_id, from_role, body) VALUES (?, ?, ?, ?)`
  ).bind(id, request_id, from_role, body).run();

  return await env.DB.prepare(`SELECT * FROM messages WHERE id = ?`).bind(id).first();
}

export async function listMessages(requestId, env) {
  const { results } = await env.DB.prepare(
    `SELECT * FROM messages WHERE request_id = ? ORDER BY created_at ASC LIMIT 200`
  ).bind(requestId).all();
  return { messages: results };
}
