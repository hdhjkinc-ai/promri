-- Run this ONLY if you already executed the original schema.sql before
-- the request/accept flow existed. Fresh deployments should just use the
-- updated schema.sql instead — running both will error on duplicate columns.

ALTER TABLE hosts ADD COLUMN contact_email TEXT;
ALTER TABLE hosts ADD COLUMN contact_phone TEXT;
ALTER TABLE consumers ADD COLUMN contact_email TEXT;
ALTER TABLE consumers ADD COLUMN contact_phone TEXT;

CREATE TABLE IF NOT EXISTS session_requests (
  id TEXT PRIMARY KEY,
  resource_id TEXT NOT NULL REFERENCES resources(id),
  host_id TEXT NOT NULL REFERENCES hosts(id),
  consumer_id TEXT NOT NULL REFERENCES consumers(id),
  status TEXT NOT NULL DEFAULT 'pending',
  chain TEXT,
  escrow_contract_address TEXT,
  share_contact INTEGER NOT NULL DEFAULT 0,
  session_id TEXT REFERENCES sessions(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  responded_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_requests_host_status ON session_requests(host_id, status);
CREATE INDEX IF NOT EXISTS idx_requests_consumer ON session_requests(consumer_id);
