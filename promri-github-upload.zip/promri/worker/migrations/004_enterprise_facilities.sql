-- Run only if you already applied schema.sql through migration 003.
-- Fresh deployments should just use the current schema.sql instead.

ALTER TABLE hosts ADD COLUMN host_type TEXT NOT NULL DEFAULT 'individual';

CREATE TABLE IF NOT EXISTS facilities (
  id TEXT PRIMARY KEY,
  host_id TEXT NOT NULL REFERENCES hosts(id),
  name TEXT NOT NULL,
  location TEXT,
  total_cpu_cores INTEGER,
  total_ram_gb INTEGER,
  total_gpu_count INTEGER,
  gpu_model TEXT,
  allocated_percentage REAL NOT NULL DEFAULT 100,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS platform_templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  base_image TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

ALTER TABLE resources ADD COLUMN facility_id TEXT REFERENCES facilities(id);
ALTER TABLE resources ADD COLUMN service_model TEXT NOT NULL DEFAULT 'iaas';
ALTER TABLE resources ADD COLUMN platform_template_id TEXT REFERENCES platform_templates(id);

CREATE INDEX IF NOT EXISTS idx_facilities_host ON facilities(host_id);
CREATE INDEX IF NOT EXISTS idx_resources_facility ON resources(facility_id);

INSERT OR IGNORE INTO platform_templates (id, name, description, base_image) VALUES
  ('tpl-node20', 'Node.js 20 app runtime', 'Push a Node app; it runs on a managed Node 20 container.', 'node:20-alpine'),
  ('tpl-python312', 'Python 3.12 app runtime', 'Push a Python app/script; managed Python 3.12 container.', 'python:3.12-slim'),
  ('tpl-postgres16', 'Postgres 16 managed DB', 'A provisioned Postgres instance — no shell access, connection string only.', 'postgres:16-alpine');
