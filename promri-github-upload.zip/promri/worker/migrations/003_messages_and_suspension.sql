-- Run this only if you already applied schema.sql / migration 002 before
-- this update. Fresh deployments should just use the current schema.sql.

ALTER TABLE consumers ADD COLUMN status TEXT NOT NULL DEFAULT 'active';
ALTER TABLE consumers ADD COLUMN strike_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE hosts ADD COLUMN strike_count INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES session_requests(id),
  from_role TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_messages_request ON messages(request_id);
