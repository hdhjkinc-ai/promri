#!/usr/bin/env bash
# PROMRI Worker deploy script — for anyone with a terminal (a computer).
# On a phone with no terminal, use the dashboard/Git path in DEPLOY.md
# instead — Cloudflare Workers Builds deploys straight from GitHub with
# no CLI at all.
#
# This will not store your token/secrets in this repo. You log into
# Cloudflare interactively (a browser tab opens via `wrangler login`) —
# there is no "paste your token into a file" step.
#
# Usage:
#   cd worker
#   npm install
#   ./deploy.sh

set -euo pipefail

command -v npx >/dev/null 2>&1 || { echo "Node.js/npm is required (for npx). Install Node first."; exit 1; }

if [ ! -d node_modules ]; then
  echo "Installing worker dependencies (viem)…"
  npm install
fi

echo "== 1/6: Cloudflare login =="
npx wrangler login

echo "== 2/6: Create (or reuse) the D1 database =="
if grep -q "REPLACE_WITH_YOUR_D1_DATABASE_ID" wrangler.toml; then
  CREATE_OUTPUT=$(npx wrangler d1 create promri)
  echo "$CREATE_OUTPUT"
  DB_ID=$(echo "$CREATE_OUTPUT" | grep -o '"database_id": *"[^"]*"' | sed 's/.*"database_id": *"\([^"]*\)"/\1/')
  if [ -z "$DB_ID" ]; then
    echo "Could not auto-detect the new database_id — copy it from the output above into wrangler.toml manually, then re-run this script."
    exit 1
  fi
  sed -i.bak "s/REPLACE_WITH_YOUR_D1_DATABASE_ID/${DB_ID}/" wrangler.toml && rm -f wrangler.toml.bak
  echo "wrangler.toml updated with database_id: $DB_ID"
else
  echo "wrangler.toml already has a database_id set — skipping creation."
fi

echo "== 3/6: Apply schema =="
npx wrangler d1 execute promri --remote --file=./schema.sql

echo "== 4/6: Apply any migrations not already folded into schema.sql =="
read -r -p "Apply migrations/*.sql now? [y/N] " APPLY_MIGRATIONS
if [[ "$APPLY_MIGRATIONS" =~ ^[Yy]$ ]]; then
  for f in migrations/*.sql; do
    echo "Applying $f ..."
    npx wrangler d1 execute promri --remote --file="$f" || echo "  (non-fatal — likely already applied, continuing)"
  done
fi

echo "== 5/6: Set secrets =="
echo "Have these ready before you start (see DEPLOY.md for where each comes from):"
echo "  EVM_RPC_URL, PLATFORM_PRIVATE_KEY, RELAY_API_KEY"
read -r -p "Set EVM_RPC_URL now? [y/N] " SET_RPC
[[ "$SET_RPC" =~ ^[Yy]$ ]] && npx wrangler secret put EVM_RPC_URL
read -r -p "Set PLATFORM_PRIVATE_KEY now? [y/N] " SET_KEY
[[ "$SET_KEY" =~ ^[Yy]$ ]] && npx wrangler secret put PLATFORM_PRIVATE_KEY
read -r -p "Set RELAY_API_KEY now? [y/N] " SET_RELAY
[[ "$SET_RELAY" =~ ^[Yy]$ ]] && npx wrangler secret put RELAY_API_KEY

echo ""
echo "Also edit wrangler.toml's [vars] block: ESCROW_CONTRACT_ADDRESS needs"
echo "your deployed PromriEscrow address (see contracts/README.md), and"
echo "EVM_CHAIN_ID should match whatever chain EVM_RPC_URL points at."
read -r -p "Press enter once wrangler.toml's [vars] are set..." _

echo "== 6/6: Deploy the Worker =="
npx wrangler deploy

echo ""
echo "Done. Your Worker URL is printed above. Put it into website/index.html"
echo "as PROMRI_API_BASE, and your contract address as PROMRI_ESCROW_ADDRESS."
