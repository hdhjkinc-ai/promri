-- PROMRI marketplace schema (Cloudflare D1 / SQLite)
-- The Worker never custodies funds or runs workloads itself — it is the
-- coordination + relay layer between the website, the host desktop app,
-- and an external chain RPC / oracle for payments and attestation.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS hosts (
  id TEXT PRIMARY KEY,               -- uuid
  wallet_address TEXT NOT NULL UNIQUE,
  display_name TEXT,
  contact_email TEXT,                -- optional, only ever shared after a request is accepted
  contact_phone TEXT,                -- optional, same rule
  reputation_score REAL NOT NULL DEFAULT 100,
  status TEXT NOT NULL DEFAULT 'active',   -- active | temp_banned | banned
  strike_count INTEGER NOT NULL DEFAULT 0, -- violations counted toward suspension tiers
  host_type TEXT NOT NULL DEFAULT 'individual',  -- individual | enterprise (multi-facility datacenter operator)
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- An enterprise host (a company running one or more actual datacenters,
-- as opposed to one person's machine) can register each physical site
-- separately and commit only a slice of it to the marketplace — e.g.
-- "40% of this facility's capacity", rather than listing one fixed box.
CREATE TABLE IF NOT EXISTS facilities (
  id TEXT PRIMARY KEY,
  host_id TEXT NOT NULL REFERENCES hosts(id),
  name TEXT NOT NULL,
  location TEXT,
  total_cpu_cores INTEGER,
  total_ram_gb INTEGER,
  total_gpu_count INTEGER,
  gpu_model TEXT,
  allocated_percentage REAL NOT NULL DEFAULT 100,  -- how much of the above is committed to PROMRI
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS consumers (
  id TEXT PRIMARY KEY,               -- uuid
  wallet_address TEXT NOT NULL UNIQUE,
  display_name TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  status TEXT NOT NULL DEFAULT 'active',      -- active | temp_suspended | suspended
  strike_count INTEGER NOT NULL DEFAULT 0,    -- non-payment / no-shows after a host accepts
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Pre-defined runtime environments for the PaaS path. An enterprise host
-- offers one of these instead of raw infrastructure access; the renter
-- pushes code/config into it, never a docker command directly.
CREATE TABLE IF NOT EXISTS platform_templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,                -- e.g. "Node.js 20 app runtime", "Postgres 16 managed DB"
  description TEXT,
  base_image TEXT NOT NULL,          -- the underlying image the host's Docker layer runs — never renter-editable
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS resources (
  id TEXT PRIMARY KEY,               -- uuid
  host_id TEXT NOT NULL REFERENCES hosts(id),
  facility_id TEXT REFERENCES facilities(id),  -- null for an individual host's own machine
  cpu_cores INTEGER,
  ram_gb INTEGER,
  gpu_model TEXT,
  bandwidth_gb REAL,
  price_per_hour REAL NOT NULL,      -- denominated in USDC (or platform unit)
  status TEXT NOT NULL DEFAULT 'holding',  -- holding | available | requested | in_session | disabled
  hardware_attestation_id TEXT,
  service_model TEXT NOT NULL DEFAULT 'iaas',  -- iaas: renter gets raw container/SSH access.
                                                -- paas: renter gets a pre-configured platform_templates
                                                -- runtime only — no direct Docker/shell commands exposed.
  platform_template_id TEXT REFERENCES platform_templates(id),  -- required when service_model = 'paas'
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- A request sits between "browsing" and "session started". The host must
-- explicitly accept or decline; acceptance is blocked unless the relay
-- confirms the renter's escrow is actually funded, so a host can never
-- accidentally start work for money that isn't really there.
CREATE TABLE IF NOT EXISTS session_requests (
  id TEXT PRIMARY KEY,
  resource_id TEXT NOT NULL REFERENCES resources(id),
  host_id TEXT NOT NULL REFERENCES hosts(id),
  consumer_id TEXT NOT NULL REFERENCES consumers(id),
  status TEXT NOT NULL DEFAULT 'pending',  -- pending | accepted | declined | expired
  chain TEXT,
  escrow_contract_address TEXT,
  share_contact INTEGER NOT NULL DEFAULT 0,  -- both sides agreed to exchange email/phone on acceptance
  session_id TEXT REFERENCES sessions(id),   -- filled in once accepted
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  responded_at TEXT
);

CREATE TABLE IF NOT EXISTS attestations (
  id TEXT PRIMARY KEY,
  host_id TEXT NOT NULL REFERENCES hosts(id),
  resource_id TEXT REFERENCES resources(id),
  report_json TEXT NOT NULL,         -- raw hardware/telemetry snapshot from host app
  verified INTEGER NOT NULL DEFAULT 0,  -- 0/1, set once oracle confirms
  oracle_ref TEXT,                   -- external oracle job/tx id
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  resource_id TEXT NOT NULL REFERENCES resources(id),
  host_id TEXT NOT NULL REFERENCES hosts(id),
  consumer_id TEXT NOT NULL REFERENCES consumers(id),
  status TEXT NOT NULL DEFAULT 'pending',  -- pending | active | completed | terminated
  chain TEXT,                        -- e.g. 'base', 'arbitrum'
  escrow_contract_address TEXT,
  stream_id TEXT,                    -- external payment-stream reference
  price_per_hour REAL NOT NULL,
  started_at TEXT,
  ended_at TEXT,
  termination_reason TEXT,           -- null | 'renter_end' | 'time_limit' | 'violation:<type>'
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS relay_log (
  id TEXT PRIMARY KEY,
  session_id TEXT REFERENCES sessions(id),
  action TEXT NOT NULL,              -- 'open_stream' | 'close_stream' | 'slash' | 'attest'
  chain TEXT,
  request_json TEXT,
  response_json TEXT,
  status TEXT NOT NULL,              -- 'ok' | 'error'
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS violations (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES sessions(id),
  violation_type TEXT NOT NULL,      -- hardware_spoofing | unauthorized_process | resource_misuse | monitoring_disabled
  evidence_json TEXT NOT NULL,
  action_taken TEXT,                 -- slashed | banned | temp_banned | session_terminated
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES sessions(id),
  from_role TEXT NOT NULL,           -- 'consumer' | 'host'
  from_id TEXT NOT NULL,
  to_id TEXT NOT NULL,
  rating INTEGER NOT NULL,           -- 1-5
  comment TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Lets host and consumer talk before/around a request — never before a
-- request exists, and never exposing contact info by itself (that's a
-- separate opt-in on the request).
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES session_requests(id),
  from_role TEXT NOT NULL,           -- 'consumer' | 'host'
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_resources_status ON resources(status);
CREATE INDEX IF NOT EXISTS idx_sessions_host ON sessions(host_id);
CREATE INDEX IF NOT EXISTS idx_sessions_consumer ON sessions(consumer_id);
CREATE INDEX IF NOT EXISTS idx_feedback_to ON feedback(to_id);
CREATE INDEX IF NOT EXISTS idx_requests_host_status ON session_requests(host_id, status);
CREATE INDEX IF NOT EXISTS idx_requests_consumer ON session_requests(consumer_id);
CREATE INDEX IF NOT EXISTS idx_messages_request ON messages(request_id);
CREATE INDEX IF NOT EXISTS idx_facilities_host ON facilities(host_id);
CREATE INDEX IF NOT EXISTS idx_resources_facility ON resources(facility_id);

INSERT OR IGNORE INTO platform_templates (id, name, description, base_image) VALUES
  ('tpl-node20', 'Node.js 20 app runtime', 'Push a Node app; it runs on a managed Node 20 container.', 'node:20-alpine'),
  ('tpl-python312', 'Python 3.12 app runtime', 'Push a Python app/script; managed Python 3.12 container.', 'python:3.12-slim'),
  ('tpl-postgres16', 'Postgres 16 managed DB', 'A provisioned Postgres instance — no shell access, connection string only.', 'postgres:16-alpine');
