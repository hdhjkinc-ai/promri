const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const os = require("os");
const { execSync } = require("child_process");

const API_BASE = process.env.PROMRI_API_BASE || "https://YOUR-WORKER-SUBDOMAIN.workers.dev";

let mainWindow;
let currentSessionId = null;
let monitorInterval = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 480,
    height: 640,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
    },
  });
  mainWindow.loadFile("index.html");
}

app.whenReady().then(createWindow);
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });

// --- Hardware verification snapshot -----------------------------------
// This is the on-device script described in the spec: it gathers a
// baseline snapshot and hands it to the Worker, which relays it to the
// oracle for verification. It never claims to BE the trust root itself.
function gatherHardwareSnapshot() {
  return {
    cpu_model: os.cpus()[0]?.model,
    cpu_cores: os.cpus().length,
    ram_gb: Math.round(os.totalmem() / 1024 ** 3),
    platform: os.platform(),
    arch: os.arch(),
    uptime_s: os.uptime(),
  };
}

ipcMain.handle("submit-attestation", async (_evt, { host_id, resource_id }) => {
  const report = gatherHardwareSnapshot();
  const res = await fetch(`${API_BASE}/api/attestations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ host_id, resource_id, report }),
  }).then((r) => r.json());
  return res;
});

// --- Session telemetry + kill switch -----------------------------------
// Real enforcement (eBPF, TPM/IMA) is native, host-OS work outside the
// scope of this scaffold — this is the control surface: it shows live
// numbers and lets the host cut the session instantly, then tells the
// Worker so it can close the payment stream and free the resource.
ipcMain.handle("start-session-monitor", (_evt, { session_id }) => {
  currentSessionId = session_id;
  if (monitorInterval) clearInterval(monitorInterval);
  monitorInterval = setInterval(() => {
    const telemetry = {
      cpu_load: os.loadavg()[0],
      free_mem_gb: Math.round(os.freemem() / 1024 ** 3),
      timestamp: Date.now(),
    };
    mainWindow?.webContents.send("telemetry", telemetry);
  }, 2000);
  return { ok: true };
});

ipcMain.handle("kill-switch", async () => {
  if (!currentSessionId) return { ok: false, message: "no active session" };
  clearInterval(monitorInterval);
  const res = await fetch(`${API_BASE}/api/sessions/${currentSessionId}/close`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ reason: "renter_end" }),
  }).then((r) => r.json());
  currentSessionId = null;
  return { ok: true, result: res };
});
