const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("promri", {
  submitAttestation: (args) => ipcRenderer.invoke("submit-attestation", args),
  startSessionMonitor: (args) => ipcRenderer.invoke("start-session-monitor", args),
  killSwitch: () => ipcRenderer.invoke("kill-switch"),
  onTelemetry: (cb) => ipcRenderer.on("telemetry", (_evt, data) => cb(data)),
});
