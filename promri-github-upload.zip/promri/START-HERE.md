# Start here

You just unzipped this. Do not rearrange anything — upload this whole
folder to GitHub exactly as it is, so your repo looks like:

```
your-repo/
├── website/
├── worker/
├── contracts/
├── desktop/
├── README.md
├── DEPLOY.md
└── START-HERE.md   (this file)
```

## Step 1 — Get it onto GitHub (today, from your phone)

1. GitHub app or github.com → **New repository** → name it (e.g. `promri`) → Create.
2. Use "Add file → Upload files" (or drag the whole unzipped folder in,
   GitHub will keep the folder structure) → upload everything → Commit.

That's it for this step. Everything after this happens in the
Cloudflare dashboard and GitHub's own settings — no terminal required
unless you choose to deploy the contract yourself (Part 2 below needs
one, just that one step).

## Step 2 — Follow DEPLOY.md, in order

Open `DEPLOY.md` in this same repo (click it on github.com, it renders
nicely) and follow it top to bottom:

- **Section 0** — deploying the Worker from a phone, no terminal
  (Cloudflare Workers Builds, Git-connected)
- **Section 2** — the money/contract flow and what each piece does
- **Section 3** — the exact file + line to edit for every kind of change
  (API URL, contract address, colors, copy, etc.)

If you get stuck on one specific numbered step, tell me the exact step
number and the error you're seeing — that's faster to fix than
re-explaining the whole flow each time.
