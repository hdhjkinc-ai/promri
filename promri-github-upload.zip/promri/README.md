# PROMRI marketplace — scaffold

Four pieces, one clear division of labor:

```
website/        consumer marketplace + host dashboard (static HTML, no build step)
worker/         Cloudflare Worker + D1 — the only server, and the only thing
                that needs Cloudflare. Talks directly to the escrow contract
                via viem (no separate relay server to host).
contracts/      the actual money contract (Solidity) — deploy once to any EVM chain
desktop/        Electron host control panel — hardware snapshot, live telemetry, kill switch
```

Start with `DEPLOY.md` — it covers deploying from a phone with zero
terminal (Cloudflare Workers Builds, Git-connected, dashboard only), the
full money flow end to end, real Cloudflare free-tier numbers, and
exactly which file to edit for each kind of change.

## What each piece actually does (and doesn't)

**The Worker** owns marketplace state in D1 (hosts, resources, sessions,
requests, feedback, attestations, messages) and, for anything
money-related, calls the `PromriEscrow` contract directly using `viem`
— a JS library built for edge runtimes, so this runs as part of the same
Worker rather than needing a second server. It never holds a private key
for consumer or host funds; the platform's own operator key
(`PLATFORM_PRIVATE_KEY`) is the only one that can start/close/slash a
session, and consumers fund escrow with their own wallet, client-side,
directly against the contract.

**The contract** (`contracts/PromriEscrow.sol`) is real, compiled
Solidity — verified against OpenZeppelin 5.x while building this. It
settles per-session at close time (elapsed seconds × agreed rate,
capped at what was deposited) rather than moving tokens every second on-chain; true continuous streaming is a separate protocol (Superfluid) to
integrate later if you want it, not something rewritten from scratch here.

**Hardware/software attestation** runs as an in-Worker plausibility
heuristic (`worker/src/attestation-heuristic.js`) — bounds-checking on
self-reported specs, not cryptographic proof of hardware identity. Real
Proof-of-Hardware (TPM quotes, a validator set) is a meaningfully larger
build than this scaffold, and is flagged as such rather than faked.

**eBPF/TPM/IMA kernel enforcement, Secure Boot checks, OS cloning**:
still not included — these need native/kernel code per host OS. What's
here instead: workloads run in a fresh Docker container on the host
machine via the desktop app.

## What's new since earlier versions of this scaffold

- **Money actually moves**: a real deployable escrow contract, called
  directly from the Worker (via `chain.js`/viem) and funded directly
  from the browser (via the website's built-in wallet integration) —
  no more "you must build this yourself" stub.
- **No separate server required** — everything Cloudflare-side runs in
  one Worker. The only non-Cloudflare dependency is an RPC endpoint URL,
  and a free public testnet one needs no signup.
- **Mobile-only deploy path** documented in `DEPLOY.md` using Cloudflare
  Workers Builds (Git-connected, dashboard-driven, no CLI).
- Enterprise host tier with multi-facility, percentage-of-capacity
  commitment, and an IaaS/PaaS split per resource (see `hosts.js`).
- Request → accept flow gated on a real on-chain funded check, host↔
  consumer chat before a transaction, and tiered auto-suspension for
  both sides.

## Quick start

1. `contracts/` → deploy `PromriEscrow.sol` to a testnet (see
   `contracts/README.md` — zero signups needed to start).
2. `worker/` → `npm install && ./deploy.sh` (or the phone/dashboard path
   in `DEPLOY.md`), setting the address from step 1 plus your RPC URL.
3. `website/index.html` → set `PROMRI_API_BASE` and
   `PROMRI_ESCROW_ADDRESS` near the top, then host it anywhere static.
4. `desktop/` → `npm install && npm start` on a host's machine.

Full detail on every step, plus limits and money flow, is in `DEPLOY.md`.
